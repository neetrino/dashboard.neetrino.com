<?php
/**
 * Telegram Debug Cleanup Utility
 * Этот файл поможет очистить все дублирующиеся уведомления
 * Запустите его через браузер один раз, если проблема с дублированием продолжается
 */

// Безопасность - проверяем что это WordPress админ
if (!defined('ABSPATH')) {
    // Если файл вызван напрямую, подключаем WordPress
    require_once('../../../../../wp-config.php');
}

if (!is_admin() && !current_user_can('manage_options')) {
    wp_die('У вас нет прав для выполнения этого действия.');
}

// Убеждаемся что модуль загружен
if (class_exists('Telegram')) {
    echo "<h1>Telegram Module Cleanup</h1>";
    
    // Очищаем все транзиенты уведомлений
    $cleaned = Telegram::force_cleanup_notifications();
    echo "<p>✅ Очищено транзиентов уведомлений: <strong>$cleaned</strong></p>";
    
    // Очищаем запланированные события
    $cleared_events = 0;
    while (wp_next_scheduled('telegram_cleanup_old_transients')) {
        wp_clear_scheduled_hook('telegram_cleanup_old_transients');
        $cleared_events++;
    }
    echo "<p>✅ Очищено запланированных событий: <strong>$cleared_events</strong></p>";
    
    // Показываем текущее состояние
    global $wpdb;
    $remaining = $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->options} 
         WHERE option_name LIKE '_transient%telegram_%'"
    );
    echo "<p>📊 Осталось telegram транзиентов: <strong>$remaining</strong></p>";
    
    echo "<hr>";
    echo "<p><strong>Что было исправлено:</strong></p>";
    echo "<ul>";
    echo "<li>✅ Добавлена защита от повторной инициализации хуков</li>";
    echo "<li>✅ Добавлена проверка транзиентов для предотвращения дублирования</li>";
    echo "<li>✅ Исправлено отображение времени заказа (теперь используется часовой пояс WordPress)</li>";
    echo "<li>✅ Добавлено логирование для отладки</li>";
    echo "<li>✅ Добавлена автоматическая очистка старых транзиентов</li>";
    echo "</ul>";
    
    echo "<p><strong>Рекомендации:</strong></p>";
    echo "<ul>";
    echo "<li>Удалите этот файл после использования для безопасности</li>";
    echo "<li>Проверьте логи WordPress (wp-content/debug.log) для отслеживания работы уведомлений</li>";
    echo "<li>Если проблема повторится, проверьте что модуль не загружается несколько раз</li>";
    echo "</ul>";
    
} else {
    echo "<h1>❌ Ошибка</h1>";
    echo "<p>Модуль Telegram не найден или не активен.</p>";
}

// Добавляем кнопку возврата в админку
echo '<p><a href="' . admin_url() . '" class="button button-primary">← Вернуться в админку</a></p>';
?>
