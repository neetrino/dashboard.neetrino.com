# Remote Control Module

Универсальный модуль удаленного управления для Neetrino.

## 🎯 Функциональность

### API Commands
- **Maintenance Mode**: `/?remote_control=maintenance&mode=[open|maintenance|closed]&key=API_KEY`
- **Bitrix24 Sync**: `/?remote_control=bitrix24_sync&key=API_KEY`
- **Status Check**: `/?remote_control=status&key=API_KEY`

### Автоматическая синхронизация Bitrix24
- Ежемесячная отправка данных (1 число каждого месяца)
- Повторные попытки при неудаче (каждый час)
- Гарантированная доставка
- Статус отправки в админке

## 🔐 Безопасность

- Хешированные API ключи (SHA-256 + соль)
- Лимиты запросов (10 в час на IP)
- Логирование всех действий
- HTTPS рекомендуется для продакшена

## 🎨 Дизайн

- **Цвет**: 🟤 Коричневый `#8b4513`
- **Иконка**: `dashicons-admin-network`
- **Стиль**: Идентичный Bitrix24 модулю

## 📊 База данных

Использует те же опции WordPress что и оригинальный remote control:
- `bitrix24_remote_control_secret_hash` - хешированные ключи
- `bitrix24_remote_control_rate_limit` - лимиты запросов
- `remote_control_last_bitrix24_sync` - статус синхронизации
- `remote_control_bitrix24_sync_status` - история отправок

## 🚀 Интеграция

Модуль полностью совместим с существующими API ключами и настройками.
Все старые интеграции продолжат работать без изменений.

---

**Version**: 1.0.0  
**Author**: Neetrino  
**Created**: July 2025
